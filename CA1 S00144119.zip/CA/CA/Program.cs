﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CA
{
    class Program
    {
        static void Main(string[] args)
        {
            Book book1 = new Book("LotR", "JRR Tolkien", "11/11/1970", 1000, "Fantasy");
            Book book2= new Book("Ulysses", "James Joyce", "02/02/1922", 730, "Fictiom");
            Book book3 = new Book("The Hobbit", "JRR Tolkien", "21/09/1937", 310, "Fantasy");
            Book book4 = new Book("The C Programming Language", "B Kernighan and D Ritchie", "28/02/1978", 279, "Computing");
            Book book5 = new Book("Portrait of the Artist", "James Joyce", "29/12/1916", 299, "Literature");

            List<Book> ReadingList = new List<Book>();

            ReadingList.Add(book1);
            ReadingList.Add(book2);
            ReadingList.Add(book3);
            ReadingList.Add(book4);
            ReadingList.Add(book5);


            

        }
    }



}
