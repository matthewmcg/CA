﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CA
{
    public class Book : IComparable
    {
        public string Title { get; set; }

        public string Author { get; set; }

        public string Date { get; set; }

        public int Pages { get; set; }

        public string Genre { get; set; }



        public Book(string title, string author, string date, int pages, string genre)
        {
            Title = title;

            Author = author;

            Date = date;

            Pages = pages;

            Genre = genre;
        }

        public void Display()
        {

        }

        public override string ToString()
        {
            return $"{Title}\t{Author}\t{Date}\t{Pages}\t{Genre}";
        }

        public int CompareTo(object obj)
        {
            Book objectThatIAmComparingTo = obj as Book;

            int returnValue = this.Pages.CompareTo(objectThatIAmComparingTo.Pages);

            return returnValue;
        }


    }
}